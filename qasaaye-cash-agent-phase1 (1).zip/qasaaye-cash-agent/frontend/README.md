# Frontend — Phase 2

Next.js 15 (App Router) + Shadcn UI + Zustand + React Hook Form + Zod + Axios.
Will be scaffolded in Phase 2 to consume the backend API at /api/v1.
