import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class ReportsService {
  constructor(private prisma: PrismaService) {}

  // Dashboard summary: volumes + commission earned (= agent profit)
  async summary(from?: string, to?: string) {
    const range = dateRange(from, to);

    const [dep, wd, pendingDep, pendingWd] = await Promise.all([
      this.prisma.deposit.aggregate({
        where: { status: 'COMPLETED', deletedAt: null, ...range },
        _sum: { amount: true, commissionAmount: true, totalCharged: true },
        _count: true,
      }),
      this.prisma.withdrawal.aggregate({
        where: { status: 'COMPLETED', deletedAt: null, ...range },
        _sum: { amount: true, commissionAmount: true, netPaid: true },
        _count: true,
      }),
      this.prisma.deposit.count({
        where: { status: 'PENDING', deletedAt: null },
      }),
      this.prisma.withdrawal.count({
        where: { status: 'PENDING', deletedAt: null },
      }),
    ]);

    const depositCommission = dep._sum.commissionAmount?.toNumber() ?? 0;
    const withdrawalCommission = wd._sum.commissionAmount?.toNumber() ?? 0;

    return {
      from,
      to,
      deposits: {
        count: dep._count,
        volume: dep._sum.amount?.toNumber() ?? 0,
        cashCollected: dep._sum.totalCharged?.toNumber() ?? 0,
        commission: depositCommission,
      },
      withdrawals: {
        count: wd._count,
        volume: wd._sum.amount?.toNumber() ?? 0,
        cashPaidOut: wd._sum.netPaid?.toNumber() ?? 0,
        commission: withdrawalCommission,
      },
      totalCommission: depositCommission + withdrawalCommission,
      pending: { deposits: pendingDep, withdrawals: pendingWd },
    };
  }

  // Per-platform breakdown for the same range
  async byPlatform(from?: string, to?: string) {
    const range = dateRange(from, to);

    const [deps, wds] = await Promise.all([
      this.prisma.deposit.groupBy({
        by: ['platformId'],
        where: { status: 'COMPLETED', deletedAt: null, ...range },
        _sum: { amount: true, commissionAmount: true },
        _count: true,
      }),
      this.prisma.withdrawal.groupBy({
        by: ['platformId'],
        where: { status: 'COMPLETED', deletedAt: null, ...range },
        _sum: { amount: true, commissionAmount: true },
        _count: true,
      }),
    ]);

    const platforms = await this.prisma.platform.findMany({
      where: { deletedAt: null },
      select: { id: true, name: true },
    });

    return platforms.map((p) => {
      const d = deps.find((x) => x.platformId === p.id);
      const w = wds.find((x) => x.platformId === p.id);
      return {
        platformId: p.id,
        name: p.name,
        depositVolume: d?._sum.amount?.toNumber() ?? 0,
        depositCount: d?._count ?? 0,
        withdrawalVolume: w?._sum.amount?.toNumber() ?? 0,
        withdrawalCount: w?._count ?? 0,
        commission:
          (d?._sum.commissionAmount?.toNumber() ?? 0) +
          (w?._sum.commissionAmount?.toNumber() ?? 0),
      };
    });
  }

  // Daily series for charts (last N days)
  async dailySeries(days = 30) {
    const since = new Date();
    since.setDate(since.getDate() - days);

    const [deps, wds] = await Promise.all([
      this.prisma.deposit.findMany({
        where: {
          status: 'COMPLETED',
          deletedAt: null,
          occurredAt: { gte: since },
        },
        select: { occurredAt: true, amount: true, commissionAmount: true },
      }),
      this.prisma.withdrawal.findMany({
        where: {
          status: 'COMPLETED',
          deletedAt: null,
          occurredAt: { gte: since },
        },
        select: { occurredAt: true, amount: true, commissionAmount: true },
      }),
    ]);

    const series = new Map<
      string,
      { deposits: number; withdrawals: number; commission: number }
    >();
    const add = (
      date: Date,
      key: 'deposits' | 'withdrawals',
      amount: number,
      commission: number,
    ) => {
      const day = date.toISOString().slice(0, 10);
      const row = series.get(day) ?? {
        deposits: 0,
        withdrawals: 0,
        commission: 0,
      };
      row[key] += amount;
      row.commission += commission;
      series.set(day, row);
    };

    deps.forEach((d) =>
      add(d.occurredAt, 'deposits', d.amount.toNumber(), d.commissionAmount.toNumber()),
    );
    wds.forEach((w) =>
      add(w.occurredAt, 'withdrawals', w.amount.toNumber(), w.commissionAmount.toNumber()),
    );

    return [...series.entries()]
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([date, row]) => ({ date, ...row }));
  }

  // CSV export of all completed transactions in range
  async exportCsv(from?: string, to?: string): Promise<string> {
    const range = dateRange(from, to);
    const [deps, wds] = await Promise.all([
      this.prisma.deposit.findMany({
        where: { deletedAt: null, ...range },
        include: { customer: true, platform: true },
        orderBy: { occurredAt: 'asc' },
      }),
      this.prisma.withdrawal.findMany({
        where: { deletedAt: null, ...range },
        include: { customer: true, platform: true },
        orderBy: { occurredAt: 'asc' },
      }),
    ]);

    const esc = (v: unknown) => `"${String(v ?? '').replace(/"/g, '""')}"`;
    const header =
      'date,type,customer,phone,platform,amount,commission,total,method,status,reference';
    const rows = [
      ...deps.map((d) =>
        [
          d.occurredAt.toISOString(),
          'DEPOSIT',
          d.customer.name,
          d.customer.phone,
          d.platform.name,
          d.amount,
          d.commissionAmount,
          d.totalCharged,
          d.method,
          d.status,
          d.reference ?? '',
        ]
          .map(esc)
          .join(','),
      ),
      ...wds.map((w) =>
        [
          w.occurredAt.toISOString(),
          'WITHDRAWAL',
          w.customer.name,
          w.customer.phone,
          w.platform.name,
          w.amount,
          w.commissionAmount,
          w.netPaid,
          w.method,
          w.status,
          w.reference ?? '',
        ]
          .map(esc)
          .join(','),
      ),
    ];
    return [header, ...rows].join('\n');
  }
}

function dateRange(from?: string, to?: string) {
  if (!from && !to) return {};
  return {
    occurredAt: {
      ...(from && { gte: new Date(from) }),
      ...(to && { lte: new Date(to) }),
    },
  };
}
