import {
  Controller,
  Get,
  Header,
  Query,
  UseGuards,
} from '@nestjs/common';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { ReportsService } from './reports.service';

@UseGuards(JwtAuthGuard)
@Controller('reports')
export class ReportsController {
  constructor(private reports: ReportsService) {}

  @Get('summary')
  summary(@Query('from') from?: string, @Query('to') to?: string) {
    return this.reports.summary(from, to);
  }

  @Get('by-platform')
  byPlatform(@Query('from') from?: string, @Query('to') to?: string) {
    return this.reports.byPlatform(from, to);
  }

  @Get('daily')
  daily(@Query('days') days?: string) {
    return this.reports.dailySeries(days ? Number(days) : 30);
  }

  @Get('export.csv')
  @Header('Content-Type', 'text/csv')
  @Header('Content-Disposition', 'attachment; filename="transactions.csv"')
  exportCsv(@Query('from') from?: string, @Query('to') to?: string) {
    return this.reports.exportCsv(from, to);
  }
}
