import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Query,
  Request,
  UseGuards,
} from '@nestjs/common';
import { TxStatus } from '@prisma/client';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { WithdrawalsService } from './withdrawals.service';
import { CreateWithdrawalDto } from './dto/create-withdrawal.dto';
import { UpdateStatusDto } from './dto/update-status.dto';

@UseGuards(JwtAuthGuard)
@Controller('withdrawals')
export class WithdrawalsController {
  constructor(private withdrawals: WithdrawalsService) {}

  @Post()
  create(@Body() dto: CreateWithdrawalDto, @Request() req: any) {
    return this.withdrawals.create(dto, req.user.userId);
  }

  @Get()
  findAll(
    @Query('customerId') customerId?: string,
    @Query('platformId') platformId?: string,
    @Query('status') status?: TxStatus,
    @Query('from') from?: string,
    @Query('to') to?: string,
  ) {
    return this.withdrawals.findAll({
      customerId,
      platformId,
      status,
      from,
      to,
    });
  }

  @Patch(':id/status')
  updateStatus(
    @Param('id') id: string,
    @Body() dto: UpdateStatusDto,
    @Request() req: any,
  ) {
    return this.withdrawals.updateStatus(id, dto.status, req.user.userId);
  }

  @Delete(':id')
  softDelete(@Param('id') id: string, @Request() req: any) {
    return this.withdrawals.softDelete(id, req.user.userId);
  }
}
