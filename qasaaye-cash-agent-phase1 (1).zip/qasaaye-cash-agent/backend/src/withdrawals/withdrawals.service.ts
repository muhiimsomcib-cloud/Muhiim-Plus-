import {
  BadRequestException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { TxStatus } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { AuditLogsService } from '../audit-logs/audit-logs.service';
import { NotificationsService } from '../notifications/notifications.service';
import { CreateWithdrawalDto } from './dto/create-withdrawal.dto';

@Injectable()
export class WithdrawalsService {
  constructor(
    private prisma: PrismaService,
    private config: ConfigService,
    private audit: AuditLogsService,
    private notifications: NotificationsService,
  ) {}

  // Workflow: customer requests cash-out → record PENDING → agent
  // receives funds from platform → pays customer (amount − 2%) →
  // mark COMPLETED.
  async create(dto: CreateWithdrawalDto, userId: string) {
    const rate =
      dto.commissionRate ??
      Number(this.config.get('WITHDRAWAL_COMMISSION_RATE', '0.02'));
    const commissionAmount = round2(dto.amount * rate);
    const netPaid = round2(dto.amount - commissionAmount);

    const withdrawal = await this.prisma.withdrawal.create({
      data: {
        amount: dto.amount,
        commissionRate: rate,
        commissionAmount,
        netPaid,
        method: dto.method,
        reference: dto.reference,
        note: dto.note,
        customerId: dto.customerId,
        platformId: dto.platformId,
        processedById: userId,
      },
      include: { customer: true, platform: true },
    });

    await this.audit.log(
      'WITHDRAWAL_CREATED',
      'Withdrawal',
      withdrawal.id,
      userId,
      { amount: dto.amount, netPaid },
    );

    const threshold = Number(this.config.get('LARGE_TX_THRESHOLD', '500'));
    if (dto.amount >= threshold) {
      await this.notifications.notify(
        'LARGE_WITHDRAWAL',
        'Large withdrawal recorded',
        `${withdrawal.customer.name} withdrawal of $${dto.amount} from ${withdrawal.platform.name} (pending)`,
      );
    }

    return withdrawal;
  }

  findAll(filters: {
    customerId?: string;
    platformId?: string;
    status?: TxStatus;
    from?: string;
    to?: string;
  }) {
    return this.prisma.withdrawal.findMany({
      where: {
        deletedAt: null,
        ...(filters.customerId && { customerId: filters.customerId }),
        ...(filters.platformId && { platformId: filters.platformId }),
        ...(filters.status && { status: filters.status }),
        ...((filters.from || filters.to) && {
          occurredAt: {
            ...(filters.from && { gte: new Date(filters.from) }),
            ...(filters.to && { lte: new Date(filters.to) }),
          },
        }),
      },
      include: {
        customer: { select: { id: true, name: true, phone: true } },
        platform: { select: { id: true, name: true } },
        processedBy: { select: { id: true, name: true } },
      },
      orderBy: { occurredAt: 'desc' },
    });
  }

  async updateStatus(id: string, status: TxStatus, userId: string) {
    const withdrawal = await this.prisma.withdrawal.findUnique({
      where: { id },
    });
    if (!withdrawal) throw new NotFoundException('Withdrawal not found');
    if (withdrawal.status === 'COMPLETED' && status !== 'COMPLETED')
      throw new BadRequestException(
        'Completed withdrawals cannot be reverted — record a correction instead',
      );

    const updated = await this.prisma.withdrawal.update({
      where: { id },
      data: { status },
    });
    await this.audit.log(`WITHDRAWAL_${status}`, 'Withdrawal', id, userId);
    return updated;
  }

  async softDelete(id: string, userId: string) {
    const withdrawal = await this.prisma.withdrawal.update({
      where: { id },
      data: { deletedAt: new Date() },
    });
    await this.audit.log('WITHDRAWAL_DELETED', 'Withdrawal', id, userId);
    return withdrawal;
  }
}

function round2(n: number): number {
  return Math.round(n * 100) / 100;
}
