import {
  IsEnum,
  IsNumber,
  IsOptional,
  IsPositive,
  IsString,
  Max,
  Min,
} from 'class-validator';

enum PayMethod {
  CASH = 'CASH',
  EVC_PLUS = 'EVC_PLUS',
  EDAHAB = 'EDAHAB',
  ZAAD = 'ZAAD',
  SAHAL = 'SAHAL',
  BANK = 'BANK',
}

export class CreateWithdrawalDto {
  @IsNumber()
  @IsPositive()
  amount: number;

  // Optional override of the default 2%
  @IsOptional()
  @IsNumber()
  @Min(0)
  @Max(0.5)
  commissionRate?: number;

  @IsOptional()
  @IsEnum(PayMethod)
  method?: PayMethod;

  @IsOptional()
  @IsString()
  reference?: string;

  @IsOptional()
  @IsString()
  note?: string;

  @IsString()
  customerId: string;

  @IsString()
  platformId: string;
}
