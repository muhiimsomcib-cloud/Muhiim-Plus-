import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Query,
  Request,
  UseGuards,
} from '@nestjs/common';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { CustomersService } from './customers.service';
import { CreateCustomerDto } from './dto/create-customer.dto';
import { UpdateCustomerDto } from './dto/update-customer.dto';
import { LinkAccountDto } from './dto/link-account.dto';

@UseGuards(JwtAuthGuard)
@Controller('customers')
export class CustomersController {
  constructor(private customers: CustomersService) {}

  @Post()
  create(@Body() dto: CreateCustomerDto, @Request() req: any) {
    return this.customers.create(dto, req.user.userId);
  }

  @Get()
  findAll(@Query('search') search?: string) {
    return this.customers.findAll(search);
  }

  @Get(':id')
  profile(@Param('id') id: string) {
    return this.customers.profile(id);
  }

  @Post(':id/accounts')
  linkAccount(@Param('id') id: string, @Body() dto: LinkAccountDto) {
    return this.customers.linkAccount(id, dto);
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() dto: UpdateCustomerDto) {
    return this.customers.update(id, dto);
  }

  @Delete(':id')
  softDelete(@Param('id') id: string, @Request() req: any) {
    return this.customers.softDelete(id, req.user.userId);
  }

  @Post(':id/restore')
  restore(@Param('id') id: string) {
    return this.customers.restore(id);
  }
}
