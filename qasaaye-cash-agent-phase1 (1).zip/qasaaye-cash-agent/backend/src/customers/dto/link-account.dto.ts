import { IsString } from 'class-validator';

export class LinkAccountDto {
  @IsString()
  platformId: string;

  @IsString()
  accountRef: string;
}
