import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { AuditLogsService } from '../audit-logs/audit-logs.service';
import { CreateCustomerDto } from './dto/create-customer.dto';
import { UpdateCustomerDto } from './dto/update-customer.dto';
import { LinkAccountDto } from './dto/link-account.dto';

@Injectable()
export class CustomersService {
  constructor(
    private prisma: PrismaService,
    private audit: AuditLogsService,
  ) {}

  async create(dto: CreateCustomerDto, userId: string) {
    const customer = await this.prisma.customer.create({ data: dto });
    await this.audit.log('CUSTOMER_CREATED', 'Customer', customer.id, userId);
    return customer;
  }

  findAll(search?: string) {
    return this.prisma.customer.findMany({
      where: {
        deletedAt: null,
        ...(search && {
          OR: [
            { name: { contains: search, mode: 'insensitive' } },
            { phone: { contains: search } },
          ],
        }),
      },
      orderBy: { name: 'asc' },
    });
  }

  // Full profile: accounts + recent transactions + lifetime totals
  async profile(id: string) {
    const customer = await this.prisma.customer.findUnique({
      where: { id },
      include: {
        accounts: { include: { platform: true } },
        deposits: {
          where: { deletedAt: null },
          orderBy: { occurredAt: 'desc' },
          take: 20,
        },
        withdrawals: {
          where: { deletedAt: null },
          orderBy: { occurredAt: 'desc' },
          take: 20,
        },
      },
    });
    if (!customer) throw new NotFoundException('Customer not found');

    const [depTotal, wdTotal] = await Promise.all([
      this.prisma.deposit.aggregate({
        where: { customerId: id, status: 'COMPLETED', deletedAt: null },
        _sum: { amount: true, commissionAmount: true },
        _count: true,
      }),
      this.prisma.withdrawal.aggregate({
        where: { customerId: id, status: 'COMPLETED', deletedAt: null },
        _sum: { amount: true, commissionAmount: true },
        _count: true,
      }),
    ]);

    return {
      ...customer,
      stats: {
        totalDeposited: depTotal._sum.amount?.toNumber() ?? 0,
        totalWithdrawn: wdTotal._sum.amount?.toNumber() ?? 0,
        depositCount: depTotal._count,
        withdrawalCount: wdTotal._count,
        commissionEarned:
          (depTotal._sum.commissionAmount?.toNumber() ?? 0) +
          (wdTotal._sum.commissionAmount?.toNumber() ?? 0),
      },
    };
  }

  linkAccount(customerId: string, dto: LinkAccountDto) {
    return this.prisma.customerPlatformAccount.create({
      data: { customerId, ...dto },
      include: { platform: true },
    });
  }

  update(id: string, dto: UpdateCustomerDto) {
    return this.prisma.customer.update({ where: { id }, data: dto });
  }

  async softDelete(id: string, userId: string) {
    const customer = await this.prisma.customer.update({
      where: { id },
      data: { deletedAt: new Date() },
    });
    await this.audit.log('CUSTOMER_DELETED', 'Customer', id, userId);
    return customer;
  }

  restore(id: string) {
    return this.prisma.customer.update({
      where: { id },
      data: { deletedAt: null },
    });
  }
}
