import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Query,
  Request,
  UseGuards,
} from '@nestjs/common';
import { TxStatus } from '@prisma/client';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { DepositsService } from './deposits.service';
import { CreateDepositDto } from './dto/create-deposit.dto';
import { UpdateStatusDto } from './dto/update-status.dto';

@UseGuards(JwtAuthGuard)
@Controller('deposits')
export class DepositsController {
  constructor(private deposits: DepositsService) {}

  @Post()
  create(@Body() dto: CreateDepositDto, @Request() req: any) {
    return this.deposits.create(dto, req.user.userId);
  }

  @Get()
  findAll(
    @Query('customerId') customerId?: string,
    @Query('platformId') platformId?: string,
    @Query('status') status?: TxStatus,
    @Query('from') from?: string,
    @Query('to') to?: string,
  ) {
    return this.deposits.findAll({ customerId, platformId, status, from, to });
  }

  @Patch(':id/status')
  updateStatus(
    @Param('id') id: string,
    @Body() dto: UpdateStatusDto,
    @Request() req: any,
  ) {
    return this.deposits.updateStatus(id, dto.status, req.user.userId);
  }

  @Delete(':id')
  softDelete(@Param('id') id: string, @Request() req: any) {
    return this.deposits.softDelete(id, req.user.userId);
  }
}
