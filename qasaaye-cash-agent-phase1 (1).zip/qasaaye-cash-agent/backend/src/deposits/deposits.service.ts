import {
  BadRequestException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { TxStatus } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { AuditLogsService } from '../audit-logs/audit-logs.service';
import { NotificationsService } from '../notifications/notifications.service';
import { CreateDepositDto } from './dto/create-deposit.dto';

@Injectable()
export class DepositsService {
  constructor(
    private prisma: PrismaService,
    private config: ConfigService,
    private audit: AuditLogsService,
    private notifications: NotificationsService,
  ) {}

  // Workflow: customer pays cash → record PENDING → agent credits
  // platform → mark COMPLETED. Commission = 5% added on top.
  async create(dto: CreateDepositDto, userId: string) {
    const rate =
      dto.commissionRate ??
      Number(this.config.get('DEPOSIT_COMMISSION_RATE', '0.05'));
    const commissionAmount = round2(dto.amount * rate);
    const totalCharged = round2(dto.amount + commissionAmount);

    const deposit = await this.prisma.deposit.create({
      data: {
        amount: dto.amount,
        commissionRate: rate,
        commissionAmount,
        totalCharged,
        method: dto.method,
        reference: dto.reference,
        note: dto.note,
        customerId: dto.customerId,
        platformId: dto.platformId,
        processedById: userId,
      },
      include: { customer: true, platform: true },
    });

    await this.audit.log('DEPOSIT_CREATED', 'Deposit', deposit.id, userId, {
      amount: dto.amount,
      totalCharged,
    });

    const threshold = Number(this.config.get('LARGE_TX_THRESHOLD', '500'));
    if (dto.amount >= threshold) {
      await this.notifications.notify(
        'LARGE_DEPOSIT',
        'Large deposit recorded',
        `${deposit.customer.name} deposit of $${dto.amount} to ${deposit.platform.name} (pending)`,
      );
    }

    return deposit;
  }

  findAll(filters: {
    customerId?: string;
    platformId?: string;
    status?: TxStatus;
    from?: string;
    to?: string;
  }) {
    return this.prisma.deposit.findMany({
      where: {
        deletedAt: null,
        ...(filters.customerId && { customerId: filters.customerId }),
        ...(filters.platformId && { platformId: filters.platformId }),
        ...(filters.status && { status: filters.status }),
        ...((filters.from || filters.to) && {
          occurredAt: {
            ...(filters.from && { gte: new Date(filters.from) }),
            ...(filters.to && { lte: new Date(filters.to) }),
          },
        }),
      },
      include: {
        customer: { select: { id: true, name: true, phone: true } },
        platform: { select: { id: true, name: true } },
        processedBy: { select: { id: true, name: true } },
      },
      orderBy: { occurredAt: 'desc' },
    });
  }

  async updateStatus(id: string, status: TxStatus, userId: string) {
    const deposit = await this.prisma.deposit.findUnique({ where: { id } });
    if (!deposit) throw new NotFoundException('Deposit not found');
    if (deposit.status === 'COMPLETED' && status !== 'COMPLETED')
      throw new BadRequestException(
        'Completed deposits cannot be reverted — record a correction instead',
      );

    const updated = await this.prisma.deposit.update({
      where: { id },
      data: { status },
    });
    await this.audit.log(`DEPOSIT_${status}`, 'Deposit', id, userId);
    return updated;
  }

  async softDelete(id: string, userId: string) {
    const deposit = await this.prisma.deposit.update({
      where: { id },
      data: { deletedAt: new Date() },
    });
    await this.audit.log('DEPOSIT_DELETED', 'Deposit', id, userId);
    return deposit;
  }
}

function round2(n: number): number {
  return Math.round(n * 100) / 100;
}
