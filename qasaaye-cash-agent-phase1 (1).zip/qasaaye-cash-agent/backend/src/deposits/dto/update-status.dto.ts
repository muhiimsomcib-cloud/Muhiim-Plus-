import { IsEnum } from 'class-validator';
import { TxStatus } from '@prisma/client';

export class UpdateStatusDto {
  @IsEnum(TxStatus)
  status: TxStatus;
}
