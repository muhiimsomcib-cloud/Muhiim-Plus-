import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Query,
  UseGuards,
} from '@nestjs/common';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { RolesGuard } from '../common/guards/roles.guard';
import { Roles } from '../common/decorators/roles.decorator';
import { PlatformsService } from './platforms.service';
import { CreatePlatformDto } from './dto/create-platform.dto';
import { UpdatePlatformDto } from './dto/update-platform.dto';

@UseGuards(JwtAuthGuard, RolesGuard)
@Controller('platforms')
export class PlatformsController {
  constructor(private platforms: PlatformsService) {}

  @Post()
  @Roles('ADMIN')
  create(@Body() dto: CreatePlatformDto) {
    return this.platforms.create(dto);
  }

  @Get()
  findAll(@Query('active') active?: string) {
    return this.platforms.findAll(active === 'true');
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.platforms.findOne(id);
  }

  @Patch(':id')
  @Roles('ADMIN')
  update(@Param('id') id: string, @Body() dto: UpdatePlatformDto) {
    return this.platforms.update(id, dto);
  }

  @Delete(':id')
  @Roles('ADMIN')
  softDelete(@Param('id') id: string) {
    return this.platforms.softDelete(id);
  }
}
