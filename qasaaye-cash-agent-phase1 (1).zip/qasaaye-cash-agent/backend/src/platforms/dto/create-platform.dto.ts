import { IsBoolean, IsOptional, IsString, MinLength } from 'class-validator';

export class CreatePlatformDto {
  @IsString()
  @MinLength(2)
  name: string;

  @IsOptional()
  @IsString()
  agentId?: string;

  @IsOptional()
  @IsBoolean()
  isActive?: boolean;

  @IsOptional()
  @IsString()
  note?: string;
}
