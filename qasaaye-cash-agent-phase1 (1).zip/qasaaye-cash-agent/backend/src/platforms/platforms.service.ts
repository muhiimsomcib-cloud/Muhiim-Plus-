import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CreatePlatformDto } from './dto/create-platform.dto';
import { UpdatePlatformDto } from './dto/update-platform.dto';

@Injectable()
export class PlatformsService {
  constructor(private prisma: PrismaService) {}

  create(dto: CreatePlatformDto) {
    return this.prisma.platform.create({ data: dto });
  }

  findAll(activeOnly = false) {
    return this.prisma.platform.findMany({
      where: { deletedAt: null, ...(activeOnly && { isActive: true }) },
      orderBy: { name: 'asc' },
    });
  }

  async findOne(id: string) {
    const platform = await this.prisma.platform.findUnique({
      where: { id },
      include: { _count: { select: { deposits: true, withdrawals: true } } },
    });
    if (!platform) throw new NotFoundException('Platform not found');
    return platform;
  }

  update(id: string, dto: UpdatePlatformDto) {
    return this.prisma.platform.update({ where: { id }, data: dto });
  }

  softDelete(id: string) {
    return this.prisma.platform.update({
      where: { id },
      data: { deletedAt: new Date(), isActive: false },
    });
  }
}
