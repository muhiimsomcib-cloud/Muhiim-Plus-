import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class AuditLogsService {
  constructor(private prisma: PrismaService) {}

  log(
    action: string,
    entity?: string,
    entityId?: string,
    userId?: string,
    metadata?: Record<string, unknown>,
    ipAddress?: string,
  ) {
    return this.prisma.auditLog.create({
      data: {
        action,
        entity,
        entityId,
        userId,
        ipAddress,
        metadata: metadata as any,
      },
    });
  }

  findAll(filters: { action?: string; userId?: string; entityId?: string }) {
    return this.prisma.auditLog.findMany({
      where: {
        ...(filters.action && { action: filters.action }),
        ...(filters.userId && { userId: filters.userId }),
        ...(filters.entityId && { entityId: filters.entityId }),
      },
      include: { user: { select: { id: true, name: true, email: true } } },
      orderBy: { createdAt: 'desc' },
      take: 200,
    });
  }
}
