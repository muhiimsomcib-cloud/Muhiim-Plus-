# Qasaaye Cash Agent — Phase 1 (Backend)

NestJS + Prisma + PostgreSQL system for managing a cash agent operation: customers, platforms, deposit workflows (5% commission), withdrawal workflows (2% commission), financial reports, audit logging, and admin notifications.

## Architecture

```
                    ┌──────────────┐
   Users ──HTTP──▶  │    Nginx     │  :80
                    └──────┬───────┘
              /api/*       │        /  (Phase 2)
        ┌──────────────────┴──────────────────┐
┌───────▼────────┐                  ┌─────────▼────────┐
│  NestJS API    │                  │  Next.js 15      │
│  :5000         │                  │  (Phase 2)       │
│  /api/v1       │                  └──────────────────┘
└───────┬────────┘
        │ Prisma
┌───────▼────────┐
│  PostgreSQL 16 │  (Docker volume: pgdata)
└────────────────┘
```

## Modules

| Module | Purpose |
|---|---|
| `auth` | Register/login, JWT (12h), login attempts audited with IP |
| `customers` | CRUD, search by name/phone, soft delete + restore, full profile with lifetime stats, link platform accounts |
| `platforms` | Manage betting platforms (admin only for create/edit/delete) |
| `deposits` | 5% commission: customer pays `amount + 5%`, platform credited `amount`. PENDING → COMPLETED workflow |
| `withdrawals` | 2% commission: platform debited `amount`, customer receives `amount − 2%`. Same workflow |
| `reports` | Summary (volumes, commission earned, pending counts), per-platform breakdown, 30-day daily series for charts, CSV export |
| `audit-logs` | Every sensitive action logged (who, what, when, IP, metadata). Admin-only viewing |
| `notifications` | Alerts on large transactions (≥ $500 default), personal + broadcast, mark-as-read |
| `common` | JwtAuthGuard, RolesGuard + @Roles() decorator, global exception filter |

## Commission logic

Rates are read from env (`DEPOSIT_COMMISSION_RATE=0.05`, `WITHDRAWAL_COMMISSION_RATE=0.02`) but **stored on every transaction**, so if you change the default later, historical records stay correct. A per-transaction override is allowed (capped at 50%).

- **Deposit $100** → commission $5 → customer pays **$105**, platform credited $100.
- **Withdrawal $100** → commission $2 → customer receives **$98**, platform debited $100.

Completed transactions cannot be reverted to pending — corrections must be recorded as new entries (audit integrity).

## Run with Docker

```bash
cd qasaaye-cash-agent
JWT_SECRET="your-long-random-secret" docker compose up --build
# API: http://localhost/api/v1
```

Migrations run automatically on backend start (`prisma migrate deploy`).

## Run locally (no Docker)

```bash
cd backend
npm install
cp .env.example .env     # set DATABASE_URL to a local/cloud Postgres
npx prisma migrate dev --name init
npm run start:dev        # http://localhost:5000/api/v1
```

## Key endpoints

| Method | Path | Notes |
|---|---|---|
| POST | /api/v1/auth/register | First user; promote to ADMIN in DB or seed |
| POST | /api/v1/auth/login | Returns `accessToken` |
| GET | /api/v1/customers?search= | Name or phone search |
| GET | /api/v1/customers/:id | Full profile + lifetime stats |
| POST | /api/v1/customers/:id/accounts | Link platform account ref |
| POST | /api/v1/deposits | Computes commission + totalCharged |
| PATCH | /api/v1/deposits/:id/status | PENDING → COMPLETED / FAILED / CANCELLED |
| POST | /api/v1/withdrawals | Computes commission + netPaid |
| GET | /api/v1/reports/summary?from=&to= | Dashboard numbers |
| GET | /api/v1/reports/by-platform | Per-platform volumes |
| GET | /api/v1/reports/daily?days=30 | Chart series |
| GET | /api/v1/reports/export.csv?from=&to= | CSV download |
| GET | /api/v1/audit-logs | ADMIN only |
| GET | /api/v1/notifications?unread=true | Personal + broadcast |

All endpoints except `/auth/*` require `Authorization: Bearer <token>`.

## Next: Phase 2 (Frontend)

Next.js 15 App Router with Shadcn UI tables/charts, Zustand store, React Hook Form + Zod validation, Axios client with token interceptor — dashboard, customers, deposits, withdrawals, platforms, reports pages. Then uncomment the `frontend` service in docker-compose and the `/` block in nginx.conf.
